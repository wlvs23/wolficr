
import React from 'react';
function App() {
  return <h1>Welcome to W0LFICR</h1>;
}
export default App;
